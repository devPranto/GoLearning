package controllers

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"

	"github.com/prantodev/go-ticket/package/models"
	"github.com/prantodev/go-ticket/package/util"
)

var NewTicket models.Ticket

func GetGuest(w http.ResponseWriter, r *http.Request) {
	newTicket := models.GetAllGuests()
	// for _, value := range newTicket{
	// fmt.Fprintf(w," <h2> Name : %v ,  No of ticket: %v </h2> \n", value.Name,1)	
	// }
	t, err := template.ParseFiles("package/controllers/home.html")
	fmt.Println("at render ",err)
	for i , value := range newTicket{
		fmt.Printf("%+v \n",i)
		fmt.Printf("%+v \n",value)
	}
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	
	err = t.Execute(w, newTicket)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
	
}

func CreateTickets(w http.ResponseWriter, r *http.Request) {
	CreateTicket := &models.Ticket{Name: r.FormValue("name"),Details: r.FormValue("details")}
	util.ParseBody(r, CreateTicket)
	t := CreateTicket.CreateTicket()
	res, _ := json.Marshal(t)
	w.WriteHeader(http.StatusOK)
	w.Write(res)
}
func renderTemplate(w http.ResponseWriter, tmpl string, p *models.Ticket) {
	t, err := template.ParseFiles("package/controllers/"+tmpl+".html")
	fmt.Println("at render ",err)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	
	err = t.Execute(w, p)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}
func Index(w http.ResponseWriter, r *http.Request) {
	ticket := &models.Ticket{}
	fmt.Println("at Index")
	renderTemplate(w, "edit", ticket)
}
