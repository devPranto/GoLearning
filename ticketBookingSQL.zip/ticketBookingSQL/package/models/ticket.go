package models

import (
	"github.com/jinzhu/gorm"
	"github.com/prantodev/go-ticket/package/config"
	
)

var (
	db *gorm.DB
)
type Ticket struct{
	gorm.Model
	Name string ` json:"name"` 
	Details string `json:"details"`
}
func init()  {
	config.Connect()
	db = config.GetDb()
	db.AutoMigrate(&Ticket{})
}
func (t *Ticket) CreateTicket()  *Ticket{
	db.NewRecord(t)
	db.Create(&t)
	return t
}
func GetAllGuests() []Ticket {
	var Tickets []Ticket 
	db.Find(&Tickets)
	return Tickets 
}